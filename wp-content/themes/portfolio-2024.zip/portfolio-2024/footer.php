
<footer>
    <p>&copy; <?php echo date('Y'); ?> | Vidhi Shah </p>
    <?php wp_nav_menu([
      'theme_location' => 'footer'
  ]); ?>
</footer>
<?php wp_footer(); ?>
    
</body>
</html>