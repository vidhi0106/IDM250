<?php get_header('simple'); ?>
<p>This is a 404 page template</p>

<?php get_footer(); ?>