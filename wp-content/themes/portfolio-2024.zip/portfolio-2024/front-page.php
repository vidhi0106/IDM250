<?php get_header(); ?>
<h1 class="">
  <?php echo get_the_title(); ?>
</h1>

<main id="site-content" role="main">


    
<div class="content"><?php get_the_content();?></div>
<p>This is a front-page.php template</p>
<?php get_footer(); ?>