<?php get_header(); ?>
<h1>
  <?php echo get_the_title(); ?>
</h1>
<?php echo get_the_content(); ?>
<p>This is a single.php template</p>
<?php get_footer(); ?>